package rocks.process.acrm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigiprAcrmApiApplicationTests {

    @Test
    void contextLoads() {
    }
}